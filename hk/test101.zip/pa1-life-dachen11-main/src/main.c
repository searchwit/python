#include <stdio.h>
#include <stdbool.h>

#include "life.h"
//#include "parser.h"

/* Be sure to read life.h and the other given source files to understand
 * what they provide and how they fit together.  You don't have to
 * understand all of the code, but you should understand how to call
 * parse_life() and clearterm().
 */

/* This is where your program will start.  You should make sure that it
 * is capable of accepting either one or two arguments; the first
 * argument (which is required) is a starting state in one of the Life
 * formats supported by parse_life(), and the second (which is optional)
 * is a number of generations to run before printing output and stopping.
 *
 * The autograder will always call your program with two arguments.  The
 * one-argument format (as described in the handout) is for your own
 * benefit!
 */


int main(int argc, char *argv[]) {
    int gens;
    if(argc != 2 && argc != 3) {
        printf("Error: invalid number of args");
        return -1;
    }
    if(argc == 2) {
        for(int y = 0; y < GRIDY; ++y) {
            for(int x = 0; x < GRIDX; ++x) {
                printf("%c", parse_life(argv[1])[y][x]);
            }
            printf("\n");
        }
        return 0;
    }
    else if(argv[1] == NULL) {
        printf("Error: invalid file");
        return -1;
    }
    else if(parse_life(argv[1]) == NULL) { 
        printf("Error: invalid file/the cat stepped on the keyboard");
        return -1;
    }
    
    else { //given a starting position (gen 0) and a number, output the generation at said number
    //GRIDY = 24. GRIDX = 80
/*
Failed:
Checking pentadecathlon during its oscillation    ... failed
Make test: 2blockrpent 72nd gen: failed.

Checking complex automata over many generations.
Checking a Gosper gun and resulting gliders       ... failed
Checking a centinal over its period               ... failed
Checking blinker fuse bomb until it stabilizes    ... failed
Checking r-pentomino until generation 205         ... failed

*/
//this is fine, but in the while loop things get weird...
        gens = argv[2][0] - '0';
        char generation[2][GRIDY + 2][GRIDX + 2];
        for(int y = 0; y < GRIDY + 2; ++y) {
            for(int x = 0; x < GRIDX + 2; ++x) {
                if(x == 0 || y == 0 || x == GRIDX + 1 || y == GRIDY + 1) {
                    generation[0][y][x] = DEAD;
                }
                else {
                    generation[0][y][x] = parse_life(argv[1])[y-1][x-1];
                }
            }
        }
        int k;
        k = 0;
        while(k < gens) { // > 5 gens = fail...
        //playgameoflife.com: use it as a simulator

            for(int i = 1; i < GRIDY + 1; ++i) { 
                int neighbors;
                for(int j = 1; j < GRIDX + 1; ++j) { 
                    neighbors = 0; 

                    for(int a = i-1; a < i+2; ++a) {
                        for(int b = j-1; b < j+2; ++b) {
                            if(a != i || b != j) {
                                if(generation[0][a][b] == LIVE) neighbors += 1;
                            }
                        }
                    }
                    if(generation[0][i][j] == LIVE) {
                        if(neighbors == 3 || neighbors == 2) {
                            generation[1][i][j] = LIVE;
                        }
                        else {
                            generation[1][i][j] = DEAD;
                        }
                    }
                    if(generation[0][i][j] == DEAD) {
                        if(neighbors == 3) {
                            generation[1][i][j] = LIVE;
                        }
                        else {
                            generation[1][i][j] = DEAD;
                        }
                    }
                } //end of for (j) loop
            } //end of for (i) loop

            k += 1;
            int count = 0;
            for(int p = 1; p < GRIDY + 1; ++p) {
                for(int v = 1; v < GRIDX + 1; ++v) {
                    if(generation[0][p][v] == generation[1][p][v]) {
                        count += 1;
                    }
                    generation[0][p][v] = generation[1][p][v];
                }
            }
            if(count == 80 * 24) k = gens;
        } //end of while loop
        for(int l = 1; l < GRIDY + 1; ++l) {
            for(int m = 1; m < GRIDX + 1; ++m) {
                putchar(generation[0][l][m]);
            }
            putchar('\n'); 
        }

    } //end of else block
    return 0;
}//end of main
